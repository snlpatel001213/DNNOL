<!DOCTYPE HTML>
<!--
	Prologue by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>DeepInteract</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.scrolly.min.js"></script>
		<script src="js/jquery.scrollzer.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
		</style><script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {
            $(".button").click(function(){
                togglePopUp()
            });

        });
        function togglePopUp(){
            if($(".popUp").is(":visible")){
                $(".popUp").css('display', 'none') ;
            }else{
                $(".popUp").css('display', 'block') ;
            }

        }
		</script>
	</script>
	
	
	<style>
hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

.CSSTableGenerator {
	margin:0px;padding:20px;
	width:100%;
	box-shadow: 10px 10px 5px #888888;
	border:2px solid #000000;
	
	-moz-border-radius-bottomleft:14px;
	-webkit-border-bottom-left-radius:14px;
	border-bottom-left-radius:14px;
	
	-moz-border-radius-bottomright:14px;
	-webkit-border-bottom-right-radius:14px;
	border-bottom-right-radius:14px;
	
	-moz-border-radius-topright:14px;
	-webkit-border-top-right-radius:14px;
	border-top-right-radius:14px;
	
	-moz-border-radius-topleft:14px;
	-webkit-border-top-left-radius:14px;
	border-top-left-radius:14px;
}.CSSTableGenerator table{
    border-collapse: collapse;
        border-spacing: 0;
	width:100%;
	height:100%;
	margin:0px;padding:0px;
}.CSSTableGenerator tr:last-child td:last-child {
	-moz-border-radius-bottomright:14px;
	-webkit-border-bottom-right-radius:14px;
	border-bottom-right-radius:14px;
}
.CSSTableGenerator table tr:first-child td:first-child {
	-moz-border-radius-topleft:14px;
	-webkit-border-top-left-radius:14px;
	border-top-left-radius:14px;
}
.CSSTableGenerator table tr:first-child td:last-child {
	-moz-border-radius-topright:14px;
	-webkit-border-top-right-radius:14px;
	border-top-right-radius:14px;
}.CSSTableGenerator tr:last-child td:first-child{
	-moz-border-radius-bottomleft:14px;
	-webkit-border-bottom-left-radius:14px;
	border-bottom-left-radius:14px;
}.CSSTableGenerator tr:hover td{
	background-color:#ffffff;
		

}
.CSSTableGenerator td{
	vertical-align:middle;
	
	background-color:#cccccc;

	border:1px solid #000000;
	border-width:0px 1px 1px 0px;
	text-align:left;
	padding:7px;
	font-size:12px;
	font-family:Arial;
	font-weight:bold;
	color:#000000;
}.CSSTableGenerator tr:last-child td{
	border-width:0px 1px 0px 0px;
}.CSSTableGenerator tr td:last-child{
	border-width:0px 0px 1px 0px;
}.CSSTableGenerator tr:last-child td:last-child{
	border-width:0px 0px 0px 0px;
}
.CSSTableGenerator tr:first-child td{
		background:-o-linear-gradient(bottom, #005fbf 5%, #007c4f 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #005fbf), color-stop(1, #007c4f) );
	background:-moz-linear-gradient( center top, #005fbf 5%, #007c4f 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#005fbf", endColorstr="#007c4f");	background: -o-linear-gradient(top,#005fbf,007c4f);

	background-color:#005fbf;
	border:0px solid #000000;
	text-align:center;
	border-width:0px 0px 1px 1px;
	font-size:14px;
	font-family:Arial;
	font-weight:bold;
	color:#ffffff;
}
.CSSTableGenerator tr:first-child:hover td{
	background:-o-linear-gradient(bottom, #005fbf 5%, #007c4f 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #005fbf), color-stop(1, #007c4f) );
	background:-moz-linear-gradient( center top, #005fbf 5%, #007c4f 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#005fbf", endColorstr="#007c4f");	background: -o-linear-gradient(top,#005fbf,007c4f);

	background-color:#005fbf;
}
.CSSTableGenerator tr:first-child td:first-child{
	border-width:0px 0px 1px 0px;
}
.CSSTableGenerator tr:first-child td:last-child{
	border-width:0px 0px 1px 1px;
}

bodyp{
    border:0;
    padding:5px;
    margin:5px;
    }
.popup{
position:absolute;
top:50px;
left:0;
background-color:#000;
width:80%;
height:100%;
display:block;
z-index:10;
}
.close{
    float:left;
    margin-left:50px;
    color:red;
    }
</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(function() {
    var moveLeft = 0;
    var moveDown = 0;
    $('a.popper').hover(function(e) {
   
        var target = '#' + ($(this).attr('data-popbox'));
         
        $(target).show();
        moveLeft = $(this).outerWidth();
        moveDown = ($(target).outerHeight() / 2);
    }, function() {
        var target = '#' + ($(this).attr('data-popbox'));
        $(target).hide();
    });
 
    $('a.popper').mousemove(function(e) {
        var target = '#' + ($(this).attr('data-popbox'));
         
        leftD = e.pageX + parseInt(moveLeft);
        maxRight = leftD + $(target).outerWidth();
        windowLeft = $(window).width() - 40;
        windowRight = 0;
        maxLeft = e.pageX - (parseInt(moveLeft) + $(target).outerWidth() + 20);
         
        if(maxRight > windowLeft && maxLeft > windowRight)
        {
            leftD = maxLeft;
        }
     
        topD = e.pageY - parseInt(moveDown);
        maxBottom = parseInt(e.pageY + parseInt(moveDown) + 20);
        windowBottom = parseInt(parseInt($(document).scrollTop()) + parseInt($(window).height()));
        maxTop = topD;
        windowTop = parseInt($(document).scrollTop());
        if(maxBottom > windowBottom)
        {
            topD = windowBottom - $(target).outerHeight() - 20;
        } else if(maxTop < windowTop){
            topD = windowTop + 20;
        }
     
        $(target).css('top', topD).css('left', leftD);
     
     
    });
 
});
</script>
<style>
.popbox {
    display: none;
    position: absolute;
    z-index: 99999;
    width: 500px;
    padding: 5px;
    background: #EEEFEB;
    color: #000000;
    border: 1px solid #3E9C5C;
    margin: 0px;
    -webkit-box-shadow: 0px 0px 0px 0px rgba(164, 164, 164, 1);
    box-shadow: 0px 0px 5px 0px rgba(164, 164, 164, 1);
}
.popbox h2
{
    background-color: #FC0;
    color:  #E3E5DD;
	 font-weight: bold;
    font-size: 16px;
    display: block;
    width: 100%;
    margin: -10px 0px 8px -10px;
    padding: 2px 10px;
	
}


.fakey {
    border: solid 1px; 
    color: #999;    
}

.fakey input {
    border: none;   
    outline: none;
}​
</style>
	
	</head>
	<body>

		<!-- Header -->
			<div id="header" class="skel-layers-fixed">

				<div class="top">

					<!-- Logo -->
						<div id="logo">
							<span class="image avatar48"><img src="images/111.png" alt="" /></span>
							<h1 id="title">DNNOL</h1>
							<p><b>Online DNN</b></p>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<!--
							
								Prologue's nav expects links in one of two formats:
								
								1. Hash link (scrolls to a different section within the page)
								
								   <li><a href="#foobar" id="foobar-link" class="icon fa-whatever-icon-you-want skel-layers-ignoreHref"><span class="label">Foobar</span></a></li>

								2. Standard link (sends the user to another page/site)

								   <li><a href="http://foobar.tld" id="foobar-link" class="icon fa-whatever-icon-you-want"><span class="label">Foobar</span></a></li>
							
							-->
							<ul>
								<li><a href="#top" id="top-link" class="skel-layers-ignoreHref"><span class="icon fa-home">Introduction</span></a></li>
								<li><a href="#Server_Interface" id="contact-link" class="skel-layers-ignoreHref"><span class="icon fa-envelope">Server Interface</span></a></li>
								<li><a href="#csi" id="contact-link" class="skel-layers-ignoreHref"><span class="icon a-envelope">Current Server Specification</span></a></li>
								<li><a href="# Tutorial and Test Cases" id=" Tutorial and Test Cases-link" class="skel-layers-ignoreHref"><span class="icon fa-th"> Tutorial</span></a></li>
								<li><a href="#test_cases" id="test_cases" class="skel-layers-ignoreHref"><span class="icon fa-user">Test Cases</span></a></li>
								<hr><hr><hr>
								<li><a href="http://www.iiita.ac.in" target="blank">Indian Institute of Information Technology</a></li>
								<hr><hr><hr>
								
							</ul>
						</nav>
						
				</div>
				
				<div class="bottom">

					<!-- Social Icons -->
						<ul class="icons">
							<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
							<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
							<li><a href="#" class="icon fa-github"><span class="label"></span></a></li>
							<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
							<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
						</ul>
				
				</div>
			
			</div>

		<!-- Main -->
			<div id="main">

				<!-- Intro -->
					<section id="top" class="one dark cover">
						<div class="container">

							<header>
								<h2 class="alt">DNNOL <br>1.1</h2>
								<p>Deep Neural Network Online</p>
								<hr><hr>
							</header>
							<div id="pop1" class="popbox" align="justify">
								<h2>ver :- 1.0 (Baby, born with bugs)</h2>
								<ul>
									<li>&gt; Available for smaller networks with few lacks of connections.</li>
									<li>&gt; Will have to wait for results , mail daemon is sleeping</li>
								
								</ul>
								
								
							</div>
							<marquee behavior="scroll"><u>with more customization including dropouts</u></marquee>
							<a href="#" class="popper" data-popbox="pop1">Version Info</a> 
							
							
							<footer>
								<!-- Intro<a href="# Tutorial and Test Cases" class="button scrolly"></a>--->
							</footer>

						</div>
					</section>
					
					<section id="Server_Interface" class="four">
						<div class="container" align="justify">

							<header>
								<h2><u>Server Interface</u></h2>
							</header>

							 <p>DNNOL accepts three inputs<br>1) Email Address of user where the result will be delivered.<br>2) "output of pfam batch search result" as input.<br>3) Provide the input as protein-pair, separated by space whose pfam results are submitted in section-2<br>Not getting??? Goto <a href="#Tutorial">tutorial section</a></p>

							
							<form enctype="multipart/form-data" action="file_uploader.php" method="POST">
								
							
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="1) Email" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										Select file for training &nbsp;&nbsp;<input type="file" name="training"><br>
										Select file for testing &nbsp;&nbsp;<input type="file" name="testing">

									</div>
									<div>
									Feature length &nbsp;&nbsp;
									<select name=feature>
										<?php
											for ($i=1; $i<=10000; $i++)
											{
												?>
													 <option  value="<?php echo $i;?>"><?php echo $i;?></option>
												<?php
											}
										?>
										</select>
									</div>
								</div>
								<div>
									Input dropout ratio (best performance at 0.2 ) &nbsp;&nbsp; <input type="textbox" class="fakey" name="input_dropout" value="0.2" size="5"><br><br>
									Hidden dropout ratio (best performance at 0.5) &nbsp;&nbsp;<input type="textbox" class="fakey" name="hidden_dropout" value="0.5" size="5"><br><br>
									Perceptrons in each hidden layer  &nbsp;&nbsp; <input type="textbox" class="fakey" name="hl1" placeholder="1 to 1000" size="7">&nbsp;&nbsp;<input type="textbox" class="fakey" name="hl2" placeholder="1 to 1000" size="7">&nbsp;&nbsp;<input type="textbox" class="fakey" name="hl3" placeholder="1 to 1000" size="7">
								</div>
								<div>
								Nesterov accelerated gradient (Recommanded)&nbsp;&nbsp; <input type="checkbox" name="nad" value="yes">Yes &nbsp;&nbsp;<input type="checkbox" name="nad" value="no">No<br> 
				                Adaptive rate (Recommanded)&nbsp;&nbsp; <input type="checkbox" name="ar" value="yes">Yes &nbsp;&nbsp;<input type="checkbox" name="ar" value="no">No 

								<div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT">
									</div>
								</div>
							</form>

						</div>
					</section>
			
			</div>
			<!--  Specifictions -->
			<div id="main">
				<section id="csi" class="four">
				<!-- Copyright -->
					<ul class="copyright">
						<div class="CSSTableGenerator" >
						<h2><u>Current Server Specification</u></h2>
						<Hr>
							<table >
								<tr>
									<td>
										ORGANISM NAME
									</td>
									<td >
										ACCURACY
									</td>
									<td>
										PRECISION
									</td>
									<td>
										SENSITIVITY
									</td>
									<td>
										SPECIFICITY
									</td>
								</tr>
								<tr>
									<td >
										C. elegans
									</td>
									<td>
										93.31%
									</td>
									<td>
										87.44%
									</td>
									<td>
										99.08%
									</td>
									<td>
										88.76%
									</td>
								</tr>
								<tr>
									<td >
										E. coli
									</td>
									<td>
										97.50%
									</td>
									<td>
										95.63%
									</td>
									<td>
										99.35%
									</td>
									<td>
										95.76%
									</td>
								</tr>
								<tr>
									<td >
										H. sapiens
									</td>
									<td>
										92.67%
									</td>
									<td>
										88.60%
									</td>
									<td>
										96.44%
									</td>
									<td>
										89.46%
									</td>
								</tr>
								<tr>
									<td >
										D. melanogaster
									</td>
									<td>
										89.49%
									</td>
									<td>
										88.40%
									</td>
									<td>
										90.37%
									</td>
									<td>
										88.65%
									</td>
								</tr>
								<tr>
									<td >
										S. cerevisiae
									</td>
									<td>
										94.44%
									</td>
									<td>
										93.15%
									</td>
									<td>
										95.61%
									</td>
									<td>
										93.32%
									</td>
								</tr>
							</table>
						</div>
            
					</ul>
					</section>
				
			</div>
			
			
			
			<div id="main">		
				<!--  Tutorial and Test Cases -->
					<section id=" Tutorial and Test Cases" class="two">
						<div class="container">
					
							<header>
								<h2><u>Tutorial</u></h2>
							</header>
							
							<p>Follow the instructions in the below given flowchart for easy understanding! </p>
						
							
										<a href="#" class="image fit"><img src="images/server.png" alt="" /></a>
									
								

						</div>
					</section>
			</div>
			
			
	<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
	<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
	<!----------------------------------------------------------Saccharomyces cerevisiae----------------------------------------------------------------------------------------------->

			<div id="main">
			<section id="test_cases" class="four">
				<!-- popup-->
	<div class="container">

							<header>
								<h2>Test Cases - Pseudoserver Interface (just for ease in understanding of "how to input")</h2>
							</header>

							 <p>DeepInteract accepts three inputs<br>1) Email Address of user where the result will be delivered<br>2) "output of pfam batch search result" as input<br>3) Provide the input as protein-pair, separated by space whose pfam results are submitted in section-2<br>Not getting???</p>
							 <bodyp>
							 <div class="button" align="right">Show Test Cases</div>
							 </bodyp>
	</div>
				
	<bodyp>
    <div class="popUp" style="display: none"><div class="button close">
	
	<section id="test_cases" class="four">
						<div class="container">
						    <div><u>Saccharomyces cerevisiae</u></div>
							<form action="#Server_Interface">
								<div align="center">
									<select name="organism">
									<option value="sc">Saccharomyces cerevisiae</option>
									</select>
								</div>
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="snlpatel@xyz.com" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										<textarea placeholder="2)output of pfam batch search result." name="textarea1">sp|O13297|CET1_YEAST     279    497    278    497 PF02940.10  mRNA_triPase      Domain     2   215   215    204.2     2e-60   1 CL0273   
sp|O13527|YA11B_YEAST    103    222    101    223 PF00665.21  rve               Domain     3   119   120     69.5   2.5e-19   1 CL0219   
sp|O13527|YA11B_YEAST    193    314    110    324 PB004510    Pfam-B_4510       Pfam-B    87   207   233     36.6   3.5e-09  NA NA      
sp|O13527|YA11B_YEAST    720    920    706    943 PF07727.9   RVT_2             Family    11   215   246    119.3   1.2e-34   1 CL0027   
sp|O13539|THP2_YEAST     114    244    114    245 PF09432.5   THP2              Family     1   131   132    201.5   3.7e-60   1 No_clan  
sp|O13547|CCW14_YEAST     21     84     20     84 PF05730.6   CFEM              Domain     2    66    66     32.2   6.8e-08   1 No_clan  
sp|O13547|CCW14_YEAST     39    213     27    236 PB005710    Pfam-B_5710       Pfam-B   161   337   499     20.6   0.00029  NA NA      
sp|O13549|VPS63_YEAST      2    105      1    108 PB006689    Pfam-B_6689       Pfam-B   251   354   416     31.3   2.3e-07  NA NA      
sp|O13556|YL462_YEAST      1     59      1     59 PB019429    Pfam-B_19429      Pfam-B     1    59    59    147.9   7.2e-44  NA NA      
sp|O13559|YRF14_YEAST     66    321     57    358 PB000943    Pfam-B_943        Pfam-B   265   520  1573    178.3     2e-52  NA NA      
sp|O13559|YRF14_YEAST    249   1010    210   1047 PB003762    Pfam-B_3762       Pfam-B   283   596   734     23.8   2.8e-05  NA NA      
sp|O13559|YRF14_YEAST    389    547    375    549 PF00270.24  DEAD              Domain    14   167   169     34.2   1.6e-08   1 CL0023   
sp|O13559|YRF14_YEAST    616   1026    313   1043 PB005038    Pfam-B_5038       Pfam-B   295   528   697     32.1   8.2e-08  NA NA      
sp|O13559|YRF14_YEAST    651    720    648    722 PF00271.26  Helicase_C        Family     7    76    78     34.3   1.5e-08   1 CL0023   
sp|O13559|YRF14_YEAST    778   1012    542   1041 PB000119    Pfam-B_119        Pfam-B   419   662  1428     21.8   5.9e-05  NA NA      
sp|O13559|YRF14_YEAST    779    995    762   1169 PB003648    Pfam-B_3648       Pfam-B    79   295   435     19.2   0.00097  NA NA      
sp|O13559|YRF14_YEAST    785   1016    292   1082 PB000715    Pfam-B_715        Pfam-B   123   341   813     24.7   7.9e-06  NA NA      
sp|O13559|YRF14_YEAST    786    998    211   1053 PB001554    Pfam-B_1554       Pfam-B   131   351   780     21.8   6.4e-05  NA NA      
sp|O13559|YRF14_YEAST    795   1027    762   1238 PB008587    Pfam-B_8587       Pfam-B   359   583  1080     19.8   0.00024  NA NA</textarea>
										<textarea placeholder="3)Enter two protein as a pair seperated by tab or space" name="textarea2">sp|O13297|CET1_YEAST sp|O13527|YA11B_YEAST
sp|O13527|YA11B_YEAST sp|O13539|THP2_YEAST
sp|O13547|CCW14_YEAST sp|O13549|VPS63_YEAST
sp|O13556|YL462_YEAST sp|O13559|YRF14_YEAST</textarea>
									</div>
								</div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT" >
									</div>
								</div>
							</form>

						</div>
					</section>
	
	</div></div>

    </bodyp>
	
	<!------------------------------------------------------------------------Escherichia coli-------------------------------------------------------------------->
		<bodyp>
    <div class="popUp" style="display: none"><div class="button close">
	
	<section id="test_cases" class="four">
						<div class="container">
						    <div><u>Escherichia coli</u></div>
							<form action="#Server_Interface">
								<div align="center">
									<select name="organism">
									<option value="ecoli">Escherichia coli</option>
									</select>
								</div>
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="snlpatel@xyz.com" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										<textarea placeholder="2)output of pfam batch search result." name="textarea1">Swiss-Prot|P00583|Release      1    120      1    120 PF00712.14  DNA_pol3_beta     Domain     1   120   120    143.6   2.4e-42   1 CL0060   
Swiss-Prot|P00583|Release    129    243    129    243 PF02767.11  DNA_pol3_beta_2   Domain     1   116   116    143.3     3e-42   1 CL0060   
Swiss-Prot|P00583|Release    245    365    245    365 PF02768.10  DNA_pol3_beta_3   Domain     1   121   121    149.4     3e-44   1 CL0060   
Swiss-Prot|P00962|Release     27    336     26    337 PF00749.16  tRNA-synt_1c      Domain     2   313   314    414.2  2.1e-124   1 CL0039   
Swiss-Prot|P00962|Release    339    527    339    527 PF03950.13  tRNA-synt_1c_C    Domain     1   174   174    212.4   3.5e-63   1 No_clan  
Swiss-Prot|P02358|Release      2     91      2     92 PF01250.12  Ribosomal_S6      Domain     1    91    92    112.7   5.2e-33   1 No_clan  
Swiss-Prot|P02374|Release     15     67     14     67 PF01084.15  Ribosomal_S18     Family     2    54    54     87.6   3.4e-25   1 No_clan  
Swiss-Prot|P02413|Release     27    143     26    144 PF00828.14  Ribosomal_L18e    Family     3   127   129     82.0   4.4e-23   1 No_clan  
Swiss-Prot|P02414|Release      4    131      4    132 PF00252.13  Ribosomal_L16     Family     1   132   133    170.7   1.2e-50   1 No_clan  
Swiss-Prot|P02426|Release      4     91      4     91 PF01386.14  Ribosomal_L25p    Domain     1    88    88    103.6   4.3e-30   1 No_clan  
Swiss-Prot|P02927|Release     28    299     28    300 PF13407.1   Peripla_BP_4      Family     1   256   257    215.9   5.9e-64   1 CL0144   
Swiss-Prot|P02932|Release     27    351     27    351 PF00267.16  Porin_1           Domain     1   337   337    472.3  8.4e-142   1 CL0193   
Swiss-Prot|P02934|Release     23    195     23    195 PF01389.12  OmpA_membrane     Domain     1   183   183    252.9   1.3e-75   1 CL0193   
Swiss-Prot|P02934|Release    222    317    222    319 PF00691.15  OmpA              Family     1    95    97     79.3   2.1e-22   1 No_clan  
Swiss-Prot|P03843|Release      2    136      1    136 PF02576.12  DUF150            Family     2   141   141    159.8   2.8e-47   1 No_clan  
Swiss-Prot|P05852|Release     24    307     23    307 PF00814.20  Peptidase_M22     Family     2   268   268    335.6  2.1e-100   1 CL0108   
Swiss-Prot|P06996|Release      1     26      1     26 PB004483    Pfam-B_4483       Pfam-B     2    27    27     39.3   5.4e-10  NA NA      
Swiss-Prot|P06996|Release     27    367     27    367 PF00267.16  Porin_1           Domain     1   337   337    461.5  1.6e-138   1 CL0193   
Swiss-Prot|P07015|Release      1     37      1     39 PB010638    Pfam-B_10638      Pfam-B     1    37    39     28.5   1.3e-06  NA NA      
Swiss-Prot|P07015|Release      1    116      1    116 PB019948    Pfam-B_19948      Pfam-B     1   121   121    146.2   6.8e-43  NA NA      
Swiss-Prot|P07015|Release      7     53      1     92 PB001721    Pfam-B_1721       Pfam-B     6    48    69     31.9   1.1e-07  NA NA      
Swiss-Prot|P07015|Release     12    153     12    154 PB010065    Pfam-B_10065      Pfam-B     1   138   139    122.3   1.5e-35  NA NA      
Swiss-Prot|P07015|Release     12    162      7    166 PB000435    Pfam-B_435        Pfam-B     8   188   197    101.9   4.5e-29  NA NA      
Swiss-Prot|P07015|Release     13     51     10     53 PB001648    Pfam-B_1648       Pfam-B   471   512   535     27.0   1.8e-06  NA NA      
Swiss-Prot|P07015|Release     17     47     12     65 PB019562    Pfam-B_19562      Pfam-B    27    57    84     19.9   0.00062  NA NA      
Swiss-Prot|P07015|Release     89    137     81    177 PB001648    Pfam-B_1648       Pfam-B   109   157   535     20.3    0.0002  NA NA      
Swiss-Prot|P07015|Release    219    511    207    516 PF00676.15  E1_dh             Family    15   282   300    155.2   1.5e-45   1 CL0254   
Swiss-Prot|P07015|Release    592    785    589    785 PF02779.19  Transket_pyr      Domain     4   178   178    223.8     1e-66   1 CL0254   
Swiss-Prot|P07015|Release    812    875    806    875 PB002359    Pfam-B_2359       Pfam-B    11    73    73     87.6   4.8e-25  NA NA      
Swiss-Prot|P07015|Release    900    931    863    933 PB006373    Pfam-B_6373       Pfam-B    21    52    64     32.4   9.4e-08  NA NA      
Swiss-Prot|P08885|Release      4    124      4    125 PF01678.14  DAP_epimerase     Domain     1   120   121    134.3   1.8e-39   1 CL0288   
Swiss-Prot|P08885|Release    153    268    152    268 PF01678.14  DAP_epimerase     Domain     2   121   121    116.9   4.5e-34   1 CL0288   
Swiss-Prot|P09160|Release      3    176      1    176 PF01812.15  5-FTHF_cyc-lig    Family     9   186   186    141.5   2.3e-41   1 CL0246   
Swiss-Prot|P11457|Release     10    160      6    161 PF03938.9   OmpH              Domain     3   157   158     81.0   8.5e-23   1 No_clan  
Swiss-Prot|P17963|Release      2    236      2    236 PF01370.16  Epimerase         Family     1   236   236    169.6   7.2e-50   1 CL0063   
Swiss-Prot|P17963|Release    252    299    234    300 PB015163    Pfam-B_15163      Pfam-B   418   465   466     40.0   2.9e-10  NA NA      
Swiss-Prot|P21499|Release     23     83     22     85 PF08461.5   HTH_12            Domain     2    64    66     54.8   5.5e-15   1 CL0123   
Swiss-Prot|P21507|Release     28    196     28    199 PF00270.24  DEAD              Domain     1   166   169    149.1   7.8e-44   1 CL0023   
Swiss-Prot|P21507|Release    268    343    266    343 PF00271.26  Helicase_C        Family     3    78    78     92.4   1.1e-26   1 CL0023   
Swiss-Prot|P23830|Release     50    178     45    192 PB003548    Pfam-B_3548       Pfam-B    37   162   254     36.4     1e-08  NA NA      
Swiss-Prot|P23830|Release    260    407    257    410 PF13091.1   PLDc_2            Domain     4   123   126     54.3     1e-14   1 CL0479   
Swiss-Prot|P24183|Release     44    104     43    104 PF04879.11  Molybdop_Fe4S4    Domain     2    55    55     65.7   2.3e-18   1 No_clan  
Swiss-Prot|P24183|Release    107    590    107    594 PF00384.17  Molybdopterin     Family     1   379   432    112.7   1.7e-32   1 No_clan  
Swiss-Prot|P24183|Release    494    542    493    543 PB004608    Pfam-B_4608       Pfam-B   198   246   253     33.2   3.6e-08  NA NA      
Swiss-Prot|P24183|Release    710    818    704    825 PB003513    Pfam-B_3513       Pfam-B     7   115   127    122.2   1.3e-35  NA NA      
Swiss-Prot|P24183|Release    894   1009    891   1010 PF01568.16  Molydop_binding   Domain     4   109   110     59.4   2.6e-16   1 CL0332   
Swiss-Prot|P24191|Release      1     72      1     72 PF01455.13  HupF_HypC         Family     1    68    68     88.2   2.5e-25   1 No_clan  
Swiss-Prot|P27298|Release      2     52      1     54 PB007033    Pfam-B_7033       Pfam-B     7    57    59     38.4   1.1e-09  NA NA      
Swiss-Prot|P27298|Release      3    230      1    306 PB006525    Pfam-B_6525       Pfam-B    37   245   314     40.3   3.8e-10  NA NA      
Swiss-Prot|P27298|Release     15    109     15    109 PB014518    Pfam-B_14518      Pfam-B     1    93    93     93.7   7.7e-27  NA NA      
Swiss-Prot|P27298|Release     19     98     13     98 PB019827    Pfam-B_19827      Pfam-B   276   355   355     21.8   0.00014  NA NA      
Swiss-Prot|P27298|Release     48    342     34    385 PB008039    Pfam-B_8039       Pfam-B   139   419   552     23.6   2.4e-05  NA NA      
Swiss-Prot|P27298|Release    181    221    178    221 PB019155    Pfam-B_19155      Pfam-B     8    49    49     26.5   4.9e-06  NA NA      
Swiss-Prot|P27298|Release    222    677    222    678 PF01432.15  Peptidase_M3      Family     1   457   458    579.2  6.4e-174   1 CL0126   
Swiss-Prot|P28910|Release      3     41      3     42 PF01402.16  RHH_1             Domain     1    38    39     39.1     4e-10   1 CL0057   
Swiss-Prot|P28910|Release     54    130     53    131 PF08753.6   NikR_C            Domain     2    78    79    103.1   5.1e-30   1 CL0070   
Swiss-Prot|P30871|Release      3    200      2    202 PF01928.16  CYTH              Domain     2   183   185    139.8   7.3e-41   1 CL0273   
Swiss-Prot|P31221|Release      2     95      2     95 PF02482.14  Ribosomal_S30AE   Family     1    97    97    114.9   1.7e-33   1 No_clan  
Swiss-Prot|P32049|Release     40    229     33    229 PF02390.12  Methyltransf_4    Family     5   197   197    219.5   2.1e-65   1 CL0063   
Swiss-Prot|P33643|Release     53    203     53    203 PF00849.17  PseudoU_synth_2   Family     1   164   164    109.5   1.4e-31   1 No_clan  
Swiss-Prot|P33925|Release      4    132      1    146 PF03918.9   CcmH              Family     2   132   148    175.0   4.2e-52   1 No_clan  
Swiss-Prot|P33925|Release    147    275    125    292 PB003263    Pfam-B_3263       Pfam-B   110   240   321     36.8   4.6e-09  NA NA      
Swiss-Prot|P33925|Release    288    345    282    350 PB000122    Pfam-B_122        Pfam-B   152   209   305     22.4    0.0001  NA NA </textarea>
										<textarea placeholder="3)Enter two protein as a pair seperated by tab or space" name="textarea2">sp|O13297|CET1_YEAST sp|O13527|YA11B_YEAST
Swiss-Prot|P27298|Release Swiss-Prot|P28910|Release
Swiss-Prot|P33643|Release Swiss-Prot|P00583|Release
Swiss-Prot|P00962|Release Swiss-Prot|P02426|Release
Swiss-Prot|P03843|Release Swiss-Prot|P07015|Release
Swiss-Prot|P11457|Release Swiss-Prot|P21499|Release</textarea>
									</div>
								</div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT" >
									</div>
								</div>
							</form>

						</div>
					</section>
	
	</div></div>


 </bodyp>
	<!----------------------------------------------------------Drosophila melanogaster------------------------------------------------------------------------------------------->
<bodyp>
    <div class="popUp" style="display: none"><div class="button close">
	
	<section id="test_cases" class="four">
						<div class="container">
						    <div><u>Drosophila melanogaster</u></div>
							<form action="#Server_Interface">
								<div align="center">
									<select name="organism">
									<option value="dmalano">Drosophila melanogaster</option>
									</select>
								</div>
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="snlpatel@xyz.com" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										<textarea placeholder="2)output of pfam batch search result." name="textarea1">sp|O16129|SYFM_DROME       95    183     57    195 PF01409.15  tRNA-synt_2d      Domain    35   132   247     58.2   6.7e-16   1 CL0040   
sp|O16129|SYFM_DROME      240    341    229    341 PF01409.15  tRNA-synt_2d      Domain   141   247   247    102.4   2.1e-29   1 CL0040   
sp|O16129|SYFM_DROME      356    453    356    453 PF03147.9   FDX-ACB           Domain     1    94    94     88.3   2.7e-25   1 No_clan  
sp|O44081|DKC1_DROME       46    104     46    104 PF08068.7   DKCLD             Domain     1    59    59    102.8   6.4e-30   1 No_clan  
sp|O44081|DKC1_DROME      108    224    108    224 PF01509.13  TruB_N            Family     1   149   149     71.9   6.1e-20   1 No_clan  
sp|O44081|DKC1_DROME      295    368    295    368 PF01472.15  PUA               Family     1    74    74     63.1   1.5e-17   1 CL0178   
sp|O44081|DKC1_DROME      348    407    342    408 PB004321    Pfam-B_4321       Pfam-B   406   465   500     54.0   1.9e-14  NA NA      
sp|O46043|PARG_DROME      151    494    151    495 PF05028.9   PARG_cat          Family     1   339   340    429.5  9.1e-129   1 No_clan  
sp|O46077|OR2A_DROME       66    387     66    387 PF02949.15  7tm_6             Family     1   313   313    272.8   2.7e-81   1 CL0176   
sp|O62618|MK14A_DROME      25    312     25    312 PF00069.20  Pkinase           Domain     1   260   260    239.2   3.9e-71   1 CL0016   
sp|O62618|MK14A_DROME     326    354    324    355 PB016498    Pfam-B_16498      Pfam-B     3    31    39     29.7   4.3e-07  NA NA      
sp|O76511|TYSY_DROME       37    321     36    321 PF00303.14  Thymidylat_synt   Domain     2   269   269    411.1  1.4e-123   1 No_clan  
sp|O76906|CRM_DROME         2    399      1    420 PB008929    Pfam-B_8929       Pfam-B   228   640   661    254.9   3.1e-75  NA NA      
sp|O77150|IM02_DROME        1     40      1     40 PF08194.7   DIM               Family     1    36    36     75.3   2.5e-21   1 No_clan  
sp|O77215|UNC4_DROME       81    271     72    275 PB007679    Pfam-B_7679       Pfam-B   527   714   718     29.9   3.2e-07  NA NA      
sp|O77215|UNC4_DROME       84    140     84    140 PF00046.24  Homeobox          Domain     1    57    57     75.5   1.7e-21   1 CL0123   
sp|O77215|UNC4_DROME      138    299    127    299 PB005206    Pfam-B_5206       Pfam-B   309   475   475     22.8   6.5e-05  NA NA      
sp|O77215|UNC4_DROME      167    298     80    303 PB000586    Pfam-B_586        Pfam-B   152   238   317     32.1   1.4e-07  NA NA      
sp|O77264|RTCA_DROME        9    340      9    341 PF01137.16  RTC               Domain     1   227   228    279.3   1.3e-83   1 CL0290   
sp|O77264|RTCA_DROME      186    288    185    289 PF05189.8   RTC_insert        Domain     2   102   103     65.6   3.1e-18   1 No_clan  
sp|O77459|KEN_DROME        29    120     24    129 PF00651.26  BTB               Domain     7   100   111     64.0   1.1e-17   1 CL0033   
sp|O77459|KEN_DROME        75    281     68    369 PB008938    Pfam-B_8938       Pfam-B    29   237   297     25.8   8.4e-06  NA NA      
sp|O77459|KEN_DROME       482    594    462    600 PB008588    Pfam-B_8588       Pfam-B   232   334   518     19.3   0.00036  NA NA      
sp|O77459|KEN_DROME       514    538    514    539 PF13465.1   zf-H2C2_2         Domain     1    25    26     27.1   3.2e-06   1 CL0361   
sp|O77459|KEN_DROME       567    590    567    590 PF13894.1   zf-C2H2_4         Domain     1    24    24      9.4       1.4   1 CL0361   
sp|O96553|C1TC_DROME       39    159     39    159 PF00763.18  THF_DHG_CYH       Family     1   117   117    126.6   4.6e-37   1 No_clan  
sp|O96553|C1TC_DROME      162    326    162    328 PF02882.14  THF_DHG_CYH_C     Domain     1   159   161    216.6     9e-65   1 CL0063   
sp|O96553|C1TC_DROME      349    968    349    968 PF01268.14  FTHFS             Family     1   557   557    825.0  1.9e-248   1 CL0023   
sp|O97394|SDK_DROME        80    154     71    156 PF13895.1   Ig_2              Domain     6    78    80     41.1   1.4e-10   1 CL0011   
sp|O97394|SDK_DROME       261    343    261    356 PF07679.11  I-set             Domain     1    80    90     26.9     3e-06   1 CL0011   
sp|O97394|SDK_DROME       374    450    363    450 PF07679.11  I-set             Domain    14    90    90     42.9   3.2e-11   1 CL0011   
sp|O97394|SDK_DROME       457    542    455    542 PF07679.11  I-set             Domain     3    90    90     49.3   3.2e-13   1 CL0011   
sp|O97394|SDK_DROME       547    637    546    637 PF07679.11  I-set             Domain     2    90    90     48.6   5.1e-13   1 CL0011   
sp|O97394|SDK_DROME       643    742    643    742 PF00041.16  fn3               Domain     2    85    85     44.7     1e-11   1 CL0159   
sp|O97394|SDK_DROME       758    843    757    845 PF00041.16  fn3               Domain     2    83    85     31.7   1.2e-07   1 CL0159   
sp|O97394|SDK_DROME       860    957    859    957 PF00041.16  fn3               Domain     2    85    85     35.4   8.5e-09   1 CL0159   
sp|O97394|SDK_DROME       971   1051    970   1054 PF00041.16  fn3               Domain     2    82    85     50.3   1.9e-13   1 CL0159   
sp|O97394|SDK_DROME      1069   1153   1068   1153 PF00041.16  fn3               Domain     2    85    85     39.4   4.7e-10   1 CL0159   
sp|O97394|SDK_DROME      1169   1260   1168   1260 PF00041.16  fn3               Domain     2    85    85     37.8   1.5e-09   1 CL0159   
sp|O97394|SDK_DROME      1276   1361   1274   1361 PF00041.16  fn3               Domain     3    85    85     50.8   1.3e-13   1 CL0159   
sp|O97394|SDK_DROME      1377   1457   1375   1458 PF00041.16  fn3               Domain     3    83    85     28.4   1.3e-06   1 CL0159   
sp|O97394|SDK_DROME      1477   1558   1474   1559 PF00041.16  fn3               Domain     3    84    85     45.2   7.5e-12   1 CL0159   
sp|O97394|SDK_DROME      1577   1666   1575   1667 PF00041.16  fn3               Domain     4    84    85     31.3   1.6e-07   1 CL0159   
sp|O97394|SDK_DROME      1682   1775   1681   1775 PF00041.16  fn3               Domain     2    85    85     38.5     9e-10   1 CL0159   
sp|O97394|SDK_DROME      1788   1871   1788   1872 PF00041.16  fn3               Domain     1    83    85     60.4   1.3e-16   1 CL0159   
sp|O97394|SDK_DROME      1888   1970   1887   1972 PF00041.16  fn3               Domain     2    82    85     32.5   6.8e-08   1 CL0159   
sp|P02574|ACT4_DROME        4    376      3    376 PF00022.14  Actin             Family     2   393   393    534.3  1.1e-160   1 CL0108   
sp|P02574|ACT4_DROME       25     75      6    134 PB009743    Pfam-B_9743       Pfam-B    24    74   498     58.1   1.2e-15  NA NA      
sp|P05623|A70A_DROME        1     55      1     55 PF08138.6   Sex_peptide       Family     1    56    56     96.2     7e-28   1 No_clan  
sp|P07668|CLAT_DROME       87    717     87    717 PF00755.15  Carn_acyltransf   Family     1   591   591    761.9  3.2e-229   1 CL0149   
sp|P07713|DECA_DROME      221    444    212    444 PF00688.13  TGFb_propeptide   Family    22   240   240    146.9   5.5e-43   1 No_clan  
sp|P07713|DECA_DROME      485    588    484    588 PF00019.15  TGF_beta          Domain     2   105   105    139.3   4.7e-41   1 CL0079   
sp|P08171|EST6_DROME        6    539      3    544 PF00135.23  COesterase        Domain     4   531   535    460.6  7.2e-138   1 CL0028   
sp|P08630|BTKL_DROME      193    222    192    223 PF00779.14  BTK                Motif     2    31    32     31.2   1.1e-07   1 No_clan  
sp|P08630|BTKL_DROME      263    330    250    501 PB011820    Pfam-B_11820      Pfam-B   665   710   712     17.8     0.001  NA NA      
sp|P08630|BTKL_DROME      348    394    348    394 PF00018.23  SH3_1             Domain     1    48    48     49.0   2.8e-13   1 CL0010   
sp|P08630|BTKL_DROME      410    488    410    488 PF00017.19  SH2               Domain     1    77    77     76.4     1e-21   1 CL0541   
sp|P08630|BTKL_DROME      527    777    526    777 PF07714.12  Pkinase_Tyr       Domain     2   259   259    322.8   1.1e-96   1 CL0016   
sp|P08646|RAS1_DROME        5    164      5    165 PF00071.17  Ras               Domain     1   161   162    191.6   5.8e-57   1 CL0023   
sp|P08953|TOLL_DROME        1    161      1    179 PB003430    Pfam-B_3430       Pfam-B    50   215   448     43.4   3.3e-11  NA NA      
sp|P08953|TOLL_DROME      174    233    174    233 PF13855.1   LRR_8             Repeat     1    61    61     47.3   1.2e-12   1 CL0022   
sp|P08953|TOLL_DROME      250    304    249    305 PF13855.1   LRR_8             Repeat     6    60    61     29.9   3.2e-07   1 CL0022   
sp|P08953|TOLL_DROME      367    387    367    388 PF00560.28  LRR_1             Repeat     1    20    22     16.5    0.0057   1 CL0022   
sp|P08953|TOLL_DROME      390    450    390    450 PF13855.1   LRR_8             Repeat     1    61    61     49.1   3.4e-13   1 CL0022   
sp|P08953|TOLL_DROME      498    517    498    542 PF00560.28  LRR_1             Repeat     1    19    22     12.4      0.12   1 CL0022   
sp|P08953|TOLL_DROME      631    662    630    662 PF01462.13  LRRNT             Family     2    28    28     36.8   1.8e-09   1 No_clan  
sp|P08953|TOLL_DROME      861    991    861    992 PF01582.15  TIR               Family     1   140   141    118.4   1.5e-34   1 CL0173   
sp|P09774|AST3_DROME       87    146     86    146 PF00010.21  HLH               Domain     2    55    55     62.7   1.8e-17   1 No_clan  
sp|P0CG69|UBIQP_DROME       6     74      6     74 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME      82    150     82    150 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     158    226    158    226 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     234    302    234    302 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     310    378    310    378 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     386    454    386    454 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     462    530    462    530 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     538    606    538    606 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     614    682    614    682 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P0CG69|UBIQP_DROME     690    758    690    758 PF00240.18  ubiquitin         Domain     1    69    69    115.4   5.3e-34   1 CL0072   
sp|P10041|DL_DROME         22     99     22    100 PF07657.8   MNNL              Family     1    76    77    106.6   4.3e-31   1 No_clan  
sp|P10041|DL_DROME        164    226    164    226 PF01414.14  DSL               Domain     1    63    63     86.8   6.8e-25   1 CL0001   </textarea>
										<textarea placeholder="3)Enter two protein as a pair seperated by tab or space" name="textarea2">sp|O16129|SYFM_DROME sp|O62618|MK14A_DROME
sp|O77150|IM02_DROME sp|O77215|UNC4_DROME
sp|O44081|DKC1_DROME sp|O77459|KEN_DROME
sp|O97394|SDK_DROME  sp|O97394|SDK_DROME
sp|P05623|A70A_DROME sp|P08630|BTKL_DROME
sp|P0CG69|UBIQP_DROME  sp|P10041|DL_DROME</textarea>
									</div>
								</div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT" >
									</div>
								</div>
							</form>

						</div>
					</section>
	
	</div></div>



 </bodyp>
 <!----------------------------------------------------------Homo sapiens------------------------------------------------------------------------------------------->
<bodyp>
    <div class="popUp" style="display: none"><div class="button close">
	
	<section id="test_cases" class="four">
						<div class="container">
						<div><u>Homo sapiens</u></div>
							<form action="#Server_Interface">
								<div align="center">
									<select name="organism">
									<option value="hsapi">Homo sapiens</option>
									</select>
								</div>
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="snlpatel@xyz.com" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										<textarea placeholder="2)output of pfam batch search result." name="textarea1">sp|A0AVT1|UBA6_HUMAN       61    191     60    198 PF00899.16  ThiF              Family     2   128   136     54.3   1.1e-14   1 CL0063   
sp|A0AVT1|UBA6_HUMAN      150    557     13    589 PB004707    Pfam-B_4707       Pfam-B   128   515  1003    144.0   6.4e-42  NA NA      
sp|A0AVT1|UBA6_HUMAN      374    424    371    431 PB013550    Pfam-B_13550      Pfam-B    65   115   431     21.2   0.00015  NA NA      
sp|A0AVT1|UBA6_HUMAN      460    600    459    603 PF00899.16  ThiF              Family     2   132   136    108.0     3e-31   1 CL0063   
sp|A0AVT1|UBA6_HUMAN      606    649    606    650 PF10585.4   UBA_e1_thiolCys   Domain     1    44    45     69.8   8.5e-20   1 No_clan  
sp|A0AVT1|UBA6_HUMAN      690    755    685    764 PB013550    Pfam-B_13550      Pfam-B   326   391   431     57.0   2.1e-15  NA NA      
sp|A0AVT1|UBA6_HUMAN      692    725    682    727 PB017190    Pfam-B_17190      Pfam-B    14    47    49     25.2   1.2e-05  NA NA      
sp|A0AVT1|UBA6_HUMAN      849    913    848    916 PF02134.16  UBACT             Family     2    64    67     90.3     4e-26   1 No_clan  
sp|A0AVT1|UBA6_HUMAN      921   1039    921   1043 PF09358.5   UBA_e1_C          Domain     1   121   125    108.7     2e-31   1 No_clan  
sp|A0JLT2|MED19_HUMAN      63    233     63    234 PF10278.4   Med19             Family     1   177   178    283.2   6.8e-85   1 No_clan  
sp|A1L0T0|ILVBL_HUMAN      53    214     52    219 PF02776.13  TPP_enzyme_N      Domain     2   165   172    167.2   2.2e-49   1 CL0254   
sp|A1L0T0|ILVBL_HUMAN     273    403    273    406 PF00205.17  TPP_enzyme_M      Domain     1   135   137     54.6   8.7e-15   1 CL0085   
sp|A1L0T0|ILVBL_HUMAN     467    618    467    618 PF02775.16  TPP_enzyme_C      Domain     1   153   153     96.0   1.5e-27   1 CL0254   
sp|A1X283|SPD2B_HUMAN       6    124      5    125 PF00787.19  PX                Domain     2   112   113     73.6     1e-20   1 No_clan  
sp|A1X283|SPD2B_HUMAN     161    203    158    203 PF00018.23  SH3_1             Domain     4    48    48     41.1     8e-11   1 CL0010   
sp|A1X283|SPD2B_HUMAN     228    272    227    272 PF00018.23  SH3_1             Domain     2    48    48     49.7   1.7e-13   1 CL0010   
sp|A1X283|SPD2B_HUMAN     377    419    374    419 PF00018.23  SH3_1             Domain     4    48    48     26.0   4.2e-06   1 CL0010   
sp|A1X283|SPD2B_HUMAN     855    909    854    909 PF07653.12  SH3_2             Domain     2    54    55     25.9   4.8e-06   1 CL0010   
sp|A2J422|A2J422_HUMAN      3    120      1    120 PF07686.12  V-set             Domain     3   114   114     77.3   7.7e-22   1 CL0011   
sp|A2J422|A2J422_HUMAN    139    242    138    243 PF07686.12  V-set             Domain     2   113   114     77.2   8.2e-22   1 CL0011   
sp|A2RRP1|NBAS_HUMAN       90    371     90    371 PF15492.1   Nbas_N            Family     1   282   282    591.8  1.5e-178   1 CL0186   
sp|A2RRP1|NBAS_HUMAN      725   1376    725   1379 PF08314.6   Sec39             Domain     1   711   715    481.2    4e-144   1 No_clan  
sp|A2RRP1|NBAS_HUMAN     1615   1670   1607   1684 PB010173    Pfam-B_10173      Pfam-B    40   100   189     38.8   1.1e-09  NA NA      
sp|A2RRP1|NBAS_HUMAN     1676   1713   1668   1727 PB012058    Pfam-B_12058      Pfam-B    45    82   127     31.9   1.3e-07  NA NA      
sp|A2RTX5|SYTC2_HUMAN     167    222    162    222 PF02824.16  TGS               Family     6    60    60     45.0   6.7e-12   1 CL0072   
sp|A2RTX5|SYTC2_HUMAN     185    295    109    295 PB001869    Pfam-B_1869       Pfam-B    29   122   122     53.6   2.7e-14  NA NA      
sp|A2RTX5|SYTC2_HUMAN     192    317    158    407 PB000159    Pfam-B_159        Pfam-B    94   211   865     83.1   1.9e-23  NA NA      
sp|A2RTX5|SYTC2_HUMAN     202    265    200    269 PB010485    Pfam-B_10485      Pfam-B    17    80   399     31.4   1.6e-07  NA NA      
sp|A2RTX5|SYTC2_HUMAN     251    320    247    324 PB001216    Pfam-B_1216       Pfam-B     5    73    79     53.4   2.7e-14  NA NA      
sp|A2RTX5|SYTC2_HUMAN     329    377    328    377 PF07973.9   tRNA_SAD          Domain     2    44    44     42.7   3.8e-11   1 No_clan  
sp|A2RTX5|SYTC2_HUMAN     432    594    431    595 PF00587.20  tRNA-synt_2b      Domain     2   172   173    149.2   8.1e-44   1 CL0040   
sp|A2RTX5|SYTC2_HUMAN     606    653    604    662 PB008849    Pfam-B_8849       Pfam-B     3    50   632     83.3   2.5e-23  NA NA      
sp|A2RTX5|SYTC2_HUMAN     654    697    654    698 PB001031    Pfam-B_1031       Pfam-B     1    43    44     49.9   2.5e-13  NA NA      
sp|A2RTX5|SYTC2_HUMAN     659    698    653    698 PB008438    Pfam-B_8438       Pfam-B    89   128   128     50.9   2.1e-13  NA NA      
sp|A2RTX5|SYTC2_HUMAN     670    698    670    698 PB013777    Pfam-B_13777      Pfam-B     1    29    29     39.2   4.4e-10  NA NA      
sp|A2RTX5|SYTC2_HUMAN     699    789    699    790 PF03129.15  HGTP_anticodon    Domain     1    93    94     63.3   1.5e-17   1 CL0458   </textarea>
										<textarea placeholder="3)Enter two protein as a pair seperated by tab or space" name="textarea2">sp|A0AVT1|UBA6_HUMAN sp|A0JLT2|MED19_HUMAN
sp|A0JLT2|MED19_HUMAN sp|A1X283|SPD2B_HUMAN
sp|A2RRP1|NBAS_HUMAN sp|A2RTX5|SYTC2_HUMAN</textarea>
									</div>
								</div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT" >
									</div>
								</div>
							</form>

						</div>
					</section>
	
	</div></div>


 </bodyp>
	<!----------------------------------------------------------Caenorhabditis elegans------------------------------------------------------------------------------------------->
<bodyp>
    <div class="popUp" style="display: none"><div class="button close">
	
	<section id="test_cases" class="four">
						<div class="container">
                        <div><u>Caenorhabditis elegans</u></div>
							<form action="#Server_Interface">
								<div align="center">
									<select name="organism">
									<option value="cele">Caenorhabditis elegans</option>
									</select>
								</div>
								<div class="row 50%">
									<div class="6u"><input type="text" name="email" placeholder="snlpatel@xyz.com" /></div>
								</div>
								<div class="row 50%">
									<div class="12u">
										<textarea placeholder="2)output of pfam batch search result." name="textarea1">sp|O01301|O01301_CAEEL    142    239    136    241 PF00651.26  BTB               Domain     9   109   111     38.4   9.6e-10   1 CL0033   
sp|O01422|CSN2_CAEEL        3     85      1     86 PB006466    Pfam-B_6466       Pfam-B     6    88    89    111.3   1.9e-32  NA NA      
sp|O01422|CSN2_CAEEL        7    340      4    383 PB001935    Pfam-B_1935       Pfam-B   126   491   575    226.7     1e-66  NA NA      
sp|O01422|CSN2_CAEEL      225    422    221    477 PB000935    Pfam-B_935        Pfam-B   344   421   927     28.6   4.6e-07  NA NA      
sp|O01422|CSN2_CAEEL      310    412    309    413 PF01399.22  PCI               Family     2   104   105     81.4   4.8e-23   1 CL0123   
sp|O01426|O01426_CAEEL      6    249      6    251 PF03029.12  ATP_bind_1        Family     1   236   238    260.3   1.5e-77   1 CL0023   
sp|O01426|O01426_CAEEL    178    248    146    249 PB002347    Pfam-B_2347       Pfam-B   383   453   741     46.8     2e-12  NA NA      
sp|O01427|AIR2_CAEEL       30    280     30    280 PF00069.20  Pkinase           Domain     1   260   260    238.8   5.1e-71   1 CL0016   
sp|O01460|O01460_CAEEL      4    175      2    175 PF06852.7   DUF1248           Family     4   181   181     37.9     1e-09   1 CL0257   
sp|O01482|O01482_CAEEL     17     90     11    144 PB013691    Pfam-B_13691      Pfam-B     9    76   370     29.7   3.7e-07  NA NA      
sp|O01482|O01482_CAEEL     21     68     20     68 PF13639.1   zf-RING_2         Domain     2    44    44     30.8   1.8e-07   1 CL0229   
sp|O01488|O01488_CAEEL     38    124     37    124 PF10241.4   KxDL              Domain     2    88    88     68.3   3.9e-19   1 No_clan  
sp|O01489|O01489_CAEEL     46    205     37    221 PB003670    Pfam-B_3670       Pfam-B   130   285   581     20.1   0.00038  NA NA      
sp|O01489|O01489_CAEEL     61    199     51    221 PB001959    Pfam-B_1959       Pfam-B    69   205   650     18.3   0.00086  NA NA      
sp|O01489|O01489_CAEEL    109    219     18    222 PB003555    Pfam-B_3555       Pfam-B    98   208   435     21.7   0.00011  NA NA      
sp|O01497|O01497_CAEEL    137    320    134    322 PF00264.15  Tyrosinase        Domain     4   221   223    116.6   1.7e-33   1 CL0205   
sp|O01497|O01497_CAEEL    457    492    457    492 PF01549.19  ShK               Domain     1    38    38     28.3   1.6e-06   1 CL0213   
sp|O01497|O01497_CAEEL    502    536    501    536 PF01549.19  ShK               Domain     2    38    38     34.0   2.7e-08   1 CL0213   
sp|O01497|O01497_CAEEL    567    602    567    602 PF01549.19  ShK               Domain     1    38    38     23.1   6.6e-05   1 CL0213   
sp|O01497|O01497_CAEEL    611    645    611    645 PF01549.19  ShK               Domain     1    38    38     34.3   2.1e-08   1 CL0213   
sp|O01498|STAM1_CAEEL      10    142      6    143 PF00790.14  VHS               Family     5   140   141     95.0   2.8e-27   1 CL0009   
sp|O01498|STAM1_CAEEL     166    367     81    373 PB007052    Pfam-B_7052       Pfam-B   450   649   757     22.1   7.4e-05  NA NA      
sp|O01498|STAM1_CAEEL     225    270    225    270 PF00018.23  SH3_1             Domain     1    48    48     59.3   1.6e-16   1 CL0010   
sp|O01502|O01502_CAEEL     62    174     60    174 PF02771.11  Acyl-CoA_dh_N     Domain     3   113   113     68.5   6.6e-19   1 CL0544   
sp|O01502|O01502_CAEEL    178    228    178    230 PF02770.14  Acyl-CoA_dh_M     Domain     1    51    52     67.0   7.2e-19   1 No_clan  
sp|O01502|O01502_CAEEL    188    295    184    312 PB001164    Pfam-B_1164       Pfam-B   445   550   678     18.2     0.001  NA NA      
sp|O01502|O01502_CAEEL    286    433    286    434 PF00441.19  Acyl-CoA_dh_1     Domain     1   148   150    148.8   1.2e-43   1 CL0087   
sp|O01530|ASP6_CAEEL       70    385     70    386 PF00026.18  Asp               Family     1   316   317    261.4   1.1e-77   1 CL0129   
sp|O01532|O01532_CAEEL     72    388     72    389 PF00026.18  Asp               Family     1   316   317    256.2   4.1e-76   1 CL0129   
sp|O01576|O01576_CAEEL      1     35      1     36 PB005624    Pfam-B_5624       Pfam-B     1    34   741     27.3   1.2e-06  NA NA      
sp|O01576|O01576_CAEEL     35    124     32    125 PF13634.1   Nucleoporin_FG    Family     3    97   114     28.6   1.2e-06   1 No_clan  
sp|O01576|O01576_CAEEL    121    207    107    210 PF13634.1   Nucleoporin_FG    Family     7    99   114     44.7   1.3e-11   1 No_clan  
sp|O01576|O01576_CAEEL    151    242    150    244 PF13634.1   Nucleoporin_FG    Family     8   100   114     54.3   1.3e-14   1 No_clan  
sp|O01576|O01576_CAEEL    239    343    236    347 PF13634.1   Nucleoporin_FG    Family     7   108   114     44.3   1.6e-11   1 No_clan  
sp|O01576|O01576_CAEEL    344    446    337    446 PF13634.1   Nucleoporin_FG    Family     7   114   114     44.2   1.9e-11   1 No_clan  
sp|O01576|O01576_CAEEL    428    532    425    550 PF13634.1   Nucleoporin_FG    Family    11   110   114     26.0     8e-06   1 No_clan  
sp|O01576|O01576_CAEEL    607    691    600    697 PF05064.8   Nsp1_C            Family    19   103   117     23.3   3.7e-05   1 No_clan  
sp|O01579|O01579_CAEEL     63    294     61    295 PF02784.11  Orn_Arg_deC_N     Domain     3   250   251     60.5   1.3e-16   1 CL0036   
sp|O01579|O01579_CAEEL    298    408    298    413 PF00278.17  Orn_DAP_Arg_deC   Domain     1   105   116     54.5     8e-15   1 No_clan  
sp|O01580|O01580_CAEEL     30    102     28    142 PB013845    Pfam-B_13845      Pfam-B     3    75   180     73.3   2.9e-20  NA NA      
sp|O01583|O01583_CAEEL     28     70     12     73 PB010499    Pfam-B_10499      Pfam-B    20    62    67     41.7   9.6e-11  NA NA      
sp|O01583|O01583_CAEEL     83    333     83    351 PF00069.20  Pkinase           Domain     1   244   260    169.7   6.4e-50   1 CL0016   
sp|O01583|O01583_CAEEL    234    697    143    724 PB000715    Pfam-B_715        Pfam-B    99   365   813     18.0   0.00085  NA NA      
sp|O01583|O01583_CAEEL    369    418    369    420 PF00433.19  Pkinase_C         Family     1    46    48     26.6   6.2e-06   1 No_clan  
sp|O01583|O01583_CAEEL    454    930    179    944 PB003822    Pfam-B_3822       Pfam-B    98   569  1292     25.8   3.1e-06  NA NA      
sp|O01583|O01583_CAEEL    701    873    685    905 PB007880    Pfam-B_7880       Pfam-B   154   317   426     21.2   0.00014  NA NA      
sp|O01583|O01583_CAEEL    958   1008    958   1010 PF00130.17  C1_1              Domain     1    51    53     43.8   1.5e-11   1 CL0006   
sp|O01583|O01583_CAEEL   1186   1473   1186   1476 PF00780.17  CNH               Family     1   272   275    141.6     3e-41   1 CL0186   
sp|O01590|O01590_CAEEL      6    194      6    196 PF13419.1   HAD_2             Family     1   174   176     66.8   2.5e-18   1 CL0137   
sp|O01590|O01590_CAEEL    251    487    250    489 PF01636.18  APH               Family     2   236   239    143.2     1e-41   1 CL0016   
sp|O01590|O01590_CAEEL    589    712    584    712 PF02771.11  Acyl-CoA_dh_N     Domain     7   113   113     40.5   3.3e-10   1 CL0544   
sp|O01590|O01590_CAEEL    716    758    716    767 PF02770.14  Acyl-CoA_dh_M     Domain     1    42    52     47.7   7.9e-13   1 No_clan  
sp|O01590|O01590_CAEEL    830    978    830    981 PF00441.19  Acyl-CoA_dh_1     Domain     1   147   150    123.6   6.7e-36   1 CL0087   
sp|O01602|O01602_CAEEL     84    146     82    150 PF00013.24  KH_1              Domain     3    56    60     34.7   9.5e-09   1 CL0007   
sp|O01602|O01602_CAEEL    270    374    269    374 PF00329.14  Complex1_30kDa    Family     2   103   103    106.7   6.1e-31   1 No_clan  
sp|O01634|INX12_CAEEL      18    379     17    380 PF00876.13  Innexin           Family     2   347   348    355.0  3.9e-106   1 No_clan  
sp|O01686|O01686_CAEEL      1     92      1     93 PF00169.24  PH                Domain     3   103   104     34.3     2e-08   1 CL0266   
sp|O01686|O01686_CAEEL      2    251      1    322 PB004571    Pfam-B_4571       Pfam-B     6   262   486     51.8   9.5e-14  NA NA      
sp|O01686|O01686_CAEEL    316    662    315    673 PF01237.13  Oxysterol_BP      Family     2   343   354    248.7   5.5e-74   1 No_clan  
sp|O01700|DLK1_CAEEL      137    374    135    376 PF00069.20  Pkinase           Domain     3   257   260    212.6     5e-63   1 CL0016   
sp|O01700|DLK1_CAEEL      141    186     98    225 PB000600    Pfam-B_600        Pfam-B   281   326   799     18.6   0.00072  NA NA      
sp|O01739|OXDD3_CAEEL      20    349     19    351 PF01266.19  DAO               Domain     2   356   358     72.0   3.9e-20   1 CL0063   
sp|O01768|O01768_CAEEL     80    122     79    124 PF00057.13  Ldl_recept_a      Repeat     2    35    37     27.5     2e-06   1 No_clan  
sp|O01768|O01768_CAEEL    130    166    128    166 PF00057.13  Ldl_recept_a      Repeat     3    37    37     28.2   1.3e-06   1 No_clan  
sp|O01768|O01768_CAEEL    743    795    735    795 PB006257    Pfam-B_6257       Pfam-B   165   217   217     65.6   5.4e-18  NA NA      
sp|O01768|O01768_CAEEL    925    959    923    964 PF00057.13  Ldl_recept_a      Repeat     3    35    37     27.4   2.2e-06   1 No_clan  
sp|O01768|O01768_CAEEL    968   1004    967   1005 PF00057.13  Ldl_recept_a      Repeat     2    36    37     31.9   8.8e-08   1 No_clan  
sp|O01768|O01768_CAEEL   1012   1047   1011   1047 PF00057.13  Ldl_recept_a      Repeat     2    37    37     32.1   7.2e-08   1 No_clan  
sp|O01768|O01768_CAEEL   1053   1087   1051   1087 PF00057.13  Ldl_recept_a      Repeat     3    37    37     37.7   1.4e-09   1 No_clan  
sp|O01768|O01768_CAEEL   1096   1129   1091   1132 PF00057.13  Ldl_recept_a      Repeat     5    36    37     26.3   4.8e-06   1 No_clan  
sp|O01768|O01768_CAEEL   1138   1175   1138   1175 PF00057.13  Ldl_recept_a      Repeat     1    37    37     31.5   1.2e-07   1 No_clan  
sp|O01768|O01768_CAEEL   1184   1216   1178   1216 PF00057.13  Ldl_recept_a      Repeat     6    37    37     28.6   9.1e-07   1 No_clan  
sp|O01768|O01768_CAEEL   1430   1550   1421   1551 PB010427    Pfam-B_10427      Pfam-B    53   168   169     37.7   1.7e-09  NA NA      
sp|O01768|O01768_CAEEL   1441   1480   1441   1481 PF00058.12  Ldl_recept_b      Repeat     1    41    42     26.3   6.5e-06   1 CL0186   
sp|O01768|O01768_CAEEL   1484   1529   1484   1530 PF00058.12  Ldl_recept_b      Repeat     1    41    42     24.4   2.6e-05   1 CL0186   
sp|O01768|O01768_CAEEL   2680   2715   2679   2715 PF00057.13  Ldl_recept_a      Repeat     2    37    37     38.6   7.2e-10   1 No_clan  
sp|O01768|O01768_CAEEL   2716   2751   2716   2751 PF00057.13  Ldl_recept_a      Repeat     2    37    37     37.1     2e-09   1 No_clan  
sp|O01768|O01768_CAEEL   2769   2798   2763   2798 PF00057.13  Ldl_recept_a      Repeat     9    37    37     37.7   1.3e-09   1 No_clan  
sp|O01768|O01768_CAEEL   2815   2851   2813   2851 PF00057.13  Ldl_recept_a      Repeat     3    37    37     38.4     8e-10   1 No_clan  
sp|O01768|O01768_CAEEL   2854   2891   2854   2891 PF00057.13  Ldl_recept_a      Repeat     1    37    37     33.0     4e-08   1 No_clan  
sp|O01768|O01768_CAEEL   2898   2938   2893   2938 PF00057.13  Ldl_recept_a      Repeat     2    37    37     43.2   2.6e-11   1 No_clan  
sp|O01768|O01768_CAEEL   2988   3025   2987   3025 PF00057.13  Ldl_recept_a      Repeat     2    37    37     33.3   3.1e-08   1 No_clan  
sp|O01768|O01768_CAEEL   3242   3357   3233   3358 PB010427    Pfam-B_10427      Pfam-B    55   168   169     31.0   1.9e-07  NA NA     </textarea>
										<textarea placeholder="3)Enter two protein as a pair seperated by tab or space" name="textarea2">sp|O01301|O01301_CAEEL sp|O01422|CSN2_CAEEL
sp|O01426|O01426_CAEEL  sp|O01482|O01482_CAEEL
sp|O01532|O01532_CAEEL sp|O01576|O01576_CAEEL
sp|O01583|O01583_CAEEL sp|O01590|O01590_CAEEL</textarea>
									</div>
								</div>
								<div class="row">
									<div class="12u">
										<input type="SUBMIT" value="SUBMIT" >
									</div>
								</div>
							</form>

						</div>
					</section>
	
	</div></div>



 </bodyp>
	
	<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
	<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
	<!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
			</section>		
			</div>
				<!-- Contact -->
					

		<!-- Footer -->
			<div id="footer">
				
				<!-- Copyright -->
					<ul class="copyright">
					<table>
					    <tr>
						<th><b><u>Backend powered by:</u></b></th>
						</tr>
					<hr>
						<tr>
							<td>
								<img width="127" height="75" src="images/perl.png"></img>
							</td>
								<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td>
								<img width="127" height="75" src="images/hadoop.png"></img>
							</td>
								<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td>
								<img width="127" height="75" src="images/h2o.png"></img>
							</td>
								<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td>
								<img width="127" height="75" src="images/R.png"></img>
							</td>
						</tr>
					</table>
					<hr>
					<table>
						<tr>
							<td>
								<a href="http://www.ipatel.org/research" target="blank"><img width="127" height="75" src="images/sunil.png"></img></a>
							</td>
								<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td>
								<img width="127" height="75" src="images/pfam.gif"></img>
							</td>
								<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<td>
								<img width="127" height="75" src="images/pritish.png"></img>
							</td>
						</tr>
					  </table>
						<li>&copy; Contact</li><li> <a href="mailto:snlpatel@hotmail.com" target="_top"> Webmaster</a></li>
					</ul>
				
			</div>

	</body>
</html>