#!"C:\xampp\perl\bin\perl.exe"

use warnings;
use File::Basename;
use File::Copy;
use Archive::Tar;
use Archive::Zip;
use Archive::Zip::Tree;
use File::Path;
$email="$ARGV[0]";
use Win32;
my $username = Win32::LoginName;
#chnging mail
##################################################################################
		$changed_mail = "$email";
		$changed_mail =~ s/\./dot/g;
		$changed_mail =~ s/\@/at/g;
		#appending random string
		my @chars = ("A".."Z");
		my $rand_string;
		$rand_string .= $chars[rand @chars] for 1..8;
		print "<h1>Your user id is - $rand_string</h1><br>";
		$changed_mail.="$rand_string";
		
##################################################################################
$feature="$ARGV[1]";
$target1="$ARGV[2]"; 
$target2="$ARGV[3]"; 
$input_dropout="$ARGV[4]"; 
$hidden_dropout="$ARGV[5]"; 
$hl1="$ARGV[6]";
$hl2="$ARGV[7]";
$hl3="$ARGV[8]";
$nad="$ARGV[9]";
$ar="$ARGV[10]";
open $R_FILE, ">C:/Users/$username/Desktop/dnnol/"."$changed_mail".'.R';

my($training_file,$dir,$ext)=fileparse($target1);
$training_file.=$ext;
move("C:/xampp/htdocs/dnnol/upload/$training_file","C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/");

my($testing_file,$dir,$ext)=fileparse($target2);
$testing_file.=$ext;
move("C:/xampp/htdocs/dnnol/upload/$testing_file","C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/");


# print "HIIIIIIIII $email $feature $target1 $target2 $input_dropout $hidden_dropout $hl1 $hl2 $hl3 $nad $ar";
#Creating R file for input 

print $R_FILE"library(h2o)\n";
print $R_FILE"library(MASS)\n";
print $R_FILE"localH2O = h2o.init(nthreads = 4,max_mem_size = \"4g\")\n";
print $R_FILE"irisPath = system.file(\"extdata\", \"$training_file\", package = \"h2o\")\n";
print $R_FILE"iris.hex = h2o.importFile(localH2O, path = irisPath)\n";
print $R_FILE"model<-h2o.deeplearning(x = 1:3542, y = 3543, data = iris.hex,  activation = \"TanhWithDropout\", # or 'Tanh'\n";
print $R_FILE"                          input_dropout_ratio = $input_dropout,\n";
print $R_FILE"                          hidden_dropout_ratios = c($hidden_dropout,$hidden_dropout,$hidden_dropout),\n";
print $R_FILE"                          epoch=10,balance_classes = TRUE, hidden = c($hl1,$hl2,$hl3),\n";
print $R_FILE"                          nesterov_accelerated_gradient=TRUE,adaptive_rate=TRUE)#,nfolds=5,override_with_best_model=TRUE\n";
print $R_FILE"print(model)\n";
print $R_FILE"test = system.file(\"extdata\", \"$testing_file\", package = \"h2o\")\n";
print $R_FILE"test.hex = h2o.importFile(localH2O, path = test)\n";
print $R_FILE"h2o_yhat_test <- h2o.predict(model, test.hex)\n";
print $R_FILE"summary(h2o_yhat_test)\n";
print $R_FILE"print(h2o_yhat_test)\n";
print $R_FILE"perf = h2o.performance(h2o_yhat_test[,3], test.hex\$class, measure = \"precision\")\n";
print $R_FILE"perf = h2o.performance(h2o_yhat_test[,3], test.hex\$class, measure = \"precision\")\n";
print $R_FILE"plot(perf, type = \"cutoffs\")\n";     # Plot precision vs. thresholds
print $R_FILE"plot(perf, type = \"roc\")  \n"   ;    # Plot ROC curve
print $R_FILE"write.matrix(h2o_yhat_test, paste(\"C:/Users/$username/Desktop/dnnol/\"$changed_mail.txt))\n";
  
