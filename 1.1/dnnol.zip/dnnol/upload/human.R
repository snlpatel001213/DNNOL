for(i in 1:15)
{
  library(h2o)
  library(MASS)
  localH2O = h2o.init(nthreads = 4,max_mem_size = "4g")
  irisPath = system.file("extdata", "train_human.csv", package = "h2o")
  iris.hex = h2o.importFile(localH2O, path = irisPath)
  model<-h2o.deeplearning(x = 1:7810, y = 7811, data = iris.hex,  activation = "Tanh", # or 'Tanh'
                          input_dropout_ratio = 0.2, # % of inputs dropout
                          hidden_dropout_ratios = c(0.5,0.5,0.5,0.5), # % for nodes dropout
                          balance_classes = TRUE, hidden = c(700,500,250,100),
                          nesterov_accelerated_gradient=TRUE,adaptive_rate=TRUE)#,nfolds=5,override_with_best_model=TRUE
  print(model)
  name<-paste('human_',i,sep="")
  h2o.saveModel(object = model, dir = "C:/Users/Decepticonn/Documents/R/win-library/3.1/h2o/extdata",name=name, save_cv = TRUE, force = TRUE)
  #model = h2o.loadModel(localH2O, "C:/Users/Decepticonn/Documents/R/win-library/3.1/h2o/extdata/paste('ecoli', '_i')")
  test = system.file("extdata", "test_human.csv", package = "h2o")
  test.hex = h2o.importFile(localH2O, path = test)
  h2o_yhat_test <- h2o.predict(model, test.hex)
  summary(h2o_yhat_test)
  print(h2o_yhat_test)
  perf = h2o.performance(h2o_yhat_test[,3], test.hex$class, measure = "precision")
  plot(perf, type = "cutoffs")     # Plot precision vs. thresholds
  plot(perf, type = "roc")         # Plot ROC curve
  write.matrix(h2o_yhat_test, paste("C:/Users/Decepticonn/Documents/R/win-library/3.1/h2o/extdata/",name))
}
h2o.shutdown(localH2O, prompt = FALSE)
