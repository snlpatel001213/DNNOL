<?php 
 $email = $_POST['email'];
 $target = "upload/"; 
 $target1 = $target . basename( $_FILES['training']['name']) ; 
 $ok=1; 
 if(move_uploaded_file($_FILES['training']['tmp_name'], $target1)) 
 {
 echo "The file ". basename( $_FILES['training']['name']). " has been uploaded";
 } 
 else {
 echo "Sorry, there was a problem uploading your file.";
 }
  $target2 = $target . basename( $_FILES['testing']['name']) ; 
 $ok=1; 
 if(move_uploaded_file($_FILES['testing']['tmp_name'], $target2)) 
 {
 echo "The file ". basename( $_FILES['testing']['name']). " has been uploaded";
 } 
 else {
 echo "Sorry, there was a problem uploading your file.";
 }
  $feature = $_POST['feature'];
  $input_dropout=$_POST['input_dropout'];
  $hidden_dropout=$_POST['hidden_dropout'];
  $hl1=$_POST['hl1'];
  $hl2=$_POST['hl2'];
  $hl3=$_POST['hl3'];
  $nad=$_POST['nad'];
  $ar=$_POST['ar'];
 echo "<h2>$email $feature $target1 $target2 $input_dropout $hidden_dropout $hl1 $hl2 $hl3 $nad $ar </h2>";
$result = exec("C:/xampp/perl/bin/perl.exe perl.pl $email $feature $target1 $target2 $input_dropout $hidden_dropout $hl1 $hl2 $hl3 $nad $ar"); # in linux $result = shell_exec(perl perl.pl)
echo $result;
 ?> 